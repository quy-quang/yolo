# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse

import sys
sys.path.insert(0, '/home/ntan/Desktop/a/face_detection')
from facedetection import detect_face

# Create your views here.
import os
import string
import random
#import base64

def helloworld(request):
    return HttpResponse("Hello World")

def add(request):
    if request.method == "GET":
        a = int(request.GET['a'])
        b = int(request.GET['b'])
        return HttpResponse(a+b)
    else:
        return HttpResponse("Non supported method")

def max_elm(request):
    if request.method == "GET":
        arr = request.GET['arr']
        arr = [int(it) for it in arr.split(',')]
        return HttpResponse(max(arr))
    else:
        return HttpResponse("Non supported method")

def detect(request):
    if request.method == "POST":
        #filename = str(request.FILES['file'])
        filename = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(64)) + '.jpg'
        handle_uploaded_file(request.FILES['file'], filename)
        faces = detect_face('media/%s'%(filename))
        return HttpResponse(filename)
    else:
        return HttpResponse("@@")

def upload(request):
    if request.method == "POST":
        #filename = str(request.FILES['file'])
        filename = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(64)) + '.jpg'
        handle_uploaded_file(request.FILES['file'], filename)
        return HttpResponse("%s saved"%(filename))
    else:
        return HttpResponse("@@")

def handle_uploaded_file(file, filename):
    if not os.path.exists('media/'):
        os.mkdir('media/')
 
    with open('media/' + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)


